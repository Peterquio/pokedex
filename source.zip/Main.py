import sys
import sqlite3
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QPushButton, QGridLayout,
                               QVBoxLayout, QListWidget, QListWidgetItem, QLabel,
                               QProgressBar, QScrollArea, QHBoxLayout)
from PySide6.QtGui import QIcon, QPixmap, QCursor
from PySide6.QtCore import QSize, Qt
from gui import Ui_MainWindow  # gerado pelo pyside6-uic

class Pokedex(QMainWindow, Ui_MainWindow):

    def carregar_pokemons(self):
        # Limpa o frame_2
        for i in reversed(range(self.frame_2.layout().count())):
            widget = self.frame_2.layout().itemAt(i).widget()
            if widget:
                widget.deleteLater()

        # Recria a lista
        self.lista = QListWidget()
        self.frame_2.layout().addWidget(self.lista)

        # Recarrega pokémons do banco
        self.cursor.execute("SELECT numero, nome FROM pokemon ORDER BY numero")
        for numero, nome in self.cursor.fetchall():
            self.lista.addItem(f"{numero:04d} - {nome}")

        # Conecta de novo o clique
        self.lista.itemClicked.connect(lambda item: self.mostrar_pokemon(item))

        """Carrega todos os pokemons para a lista inicial"""
        conn = sqlite3.connect("pokemons.db")
        cur = conn.cursor()
        cur.execute("SELECT numero, nome FROM pokemon ORDER BY numero ASC")
        pokemons = cur.fetchall()
        conn.close()

        self.lista.clear()
        for numero, nome in pokemons:
            item = QListWidgetItem(f"{numero:04d} - {nome}")
            self.lista.addItem(item)

    def mostrar_pokemon(self, item):
        """Abre tela de detalhes do pokemon"""
        texto = item.text()
        numero = int(texto.split(" - ")[0])
        self.abrir_detalhes(numero)

    def abrir_detalhes(self, numero):
        # Limpa o frame_2 e coloca scroll
        scroll = QScrollArea(self.frame_2)
        scroll.setWidgetResizable(True)

        content = QWidget(scroll)
        layout = QVBoxLayout(content)
        layout.setSpacing(3)  # espaço entre os elementos

        # Consulta dados
        self.cursor.execute("""
                            SELECT numero,
                                   nome,
                                   tipo1,
                                   tipo2,
                                   descricao,
                                   pre_evolucoes,
                                   evolucoes,
                                   ps,
                                   ataque,
                                   defesa,
                                   ataque_especial,
                                   defesa_especial,
                                   velocidade
                            FROM pokemon
                            WHERE numero = ?
                            """, (numero,))
        dados = self.cursor.fetchone()

        if not dados:
            return

        (numero, nome, tipo1, tipo2, descricao, pre_evo, evolucoes, ps, atk, defe, sp_atk, sp_def, vel) = dados

        # Tipos (botões com ícone futuramente)
        tipos_layout = QHBoxLayout()
        btn_tipo1 = QPushButton(tipo1, content)
        tipos_layout.addWidget(btn_tipo1)
        if tipo2:
            btn_tipo2 = QPushButton(tipo2, content)
            tipos_layout.addWidget(btn_tipo2)
        layout.addLayout(tipos_layout)

        # Stats com QProgressBar
        def add_stat(nome, valor, maximo=255):
            lbl = QLabel(f"{nome}: {valor}", content)
            bar = QProgressBar(content)
            bar.setMaximum(maximo)
            bar.setValue(valor)
            bar.setTextVisible(False)
            layout.addWidget(lbl)
            layout.addWidget(bar)

        add_stat("PS", ps)
        add_stat("Ataque", atk)
        add_stat("Defesa", defe)
        add_stat("Ataque Especial", sp_atk)
        add_stat("Defesa Especial", sp_def)
        add_stat("Velocidade", vel)

        # Evoluções
        if pre_evo:
            for name in [n.strip() for n in pre_evo.split(",") if n.strip()]:
                btn_prev = QPushButton(f"Evolui de: {name}", content)
                btn_prev.clicked.connect(lambda _, n=name: self.abrir_por_nome(n))
                layout.addWidget(btn_prev)

        if evolucoes:
            for name in [n.strip() for n in evolucoes.split(",") if n.strip()]:
                btn_evo = QPushButton(f"Evolui para: {name}", content)
                btn_evo.clicked.connect(lambda _, n=name: self.abrir_por_nome(n))
                layout.addWidget(btn_evo)

        # Descrição
        lbl_desc = QLabel(descricao, content)
        lbl_desc.setWordWrap(True)
        layout.addWidget(lbl_desc)

        # Botão voltar (fica fixo embaixo)
        btn_voltar = QPushButton("Voltar", content)
        btn_voltar.clicked.connect(self.carregar_pokemons)
        layout.addWidget(btn_voltar, alignment=Qt.AlignRight)

        scroll.setWidget(content)

        # Substitui o conteúdo do frame_2
        for i in reversed(range(self.frame_2.layout().count())):
            item = self.frame_2.layout().itemAt(i)
            w = item.widget()
            if w:
                w.deleteLater()

        self.frame_2.layout().addWidget(scroll)

        # Limpa os widgets anteriores do frame (antes de adicionar o sprite)
        layout = self.frame.layout()
        for i in reversed(range(layout.count())):
            widget = layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        # Adiciona sprite do Pokémon
        sprite = QLabel()
        pixmap = QPixmap(f"images/{numero:04d}.png")
        sprite.setPixmap(pixmap.scaled(200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        sprite.setAlignment(Qt.AlignCenter)
        layout.addWidget(sprite)

    def mostrar_lista(self):
        # coloca a lista de volta dentro do scroll
        self.scroll_area.setWidget(self.lista)

    def abrir_por_nome(self, nome):
        """Abre detalhes pelo nome (usado nas evoluções)"""
        cur = self.conn.cursor()
        cur.execute("SELECT numero FROM pokemon WHERE nome=?", (nome,))
        row = cur.fetchone()
        if row:
            self.abrir_detalhes(row[0])

    def voltar_lista(self):
        """Volta para a lista de pokemons"""
        for i in reversed(range(self.frame_2.layout().count())):
            widget = self.frame_2.layout().itemAt(i).widget()
            if widget:
                widget.deleteLater()
        self.frame_2.layout().addWidget(self.lista)

    def aplicar_filtro(self):
        """
        Chamado quando qualquer botão de tipo é clicado.
        Garante no máximo 2 botões marcados e atualiza a lista.
        """
        sender = self.sender()  # botão que foi clicado (QPushButton)
        # recalcula tipos ativos a partir das propriedades 'tipo'
        tipos_ativos = [btn.property("tipo") for btn in self.botoes_tipos.values() if btn.isChecked()]

        # Se exceder 2, desmarca o botão que acabou de ser clicado
        if len(tipos_ativos) > 2 and isinstance(sender, QPushButton):
            sender.setChecked(False)
            tipos_ativos = [btn.property("tipo") for btn in self.botoes_tipos.values() if btn.isChecked()]

        # atualiza a lista com base nos tipos ativos
        self.filtrar_pokemons(tipos_ativos)

    def filtrar_pokemons(self, tipos_ativos=None):
        """
        Atualiza self.lista com pokémons conforme filtros.
        Recebe lista de strings (ex: ['water'], ['water','fairy']) - as strings vêm do property 'tipo' dos botões.
        """
        if tipos_ativos is None:
            tipos_ativos = []

        # normalize para lower-case (vai usar LOWER(...) no SQL)
        tipos_norm = [t.lower() for t in tipos_ativos]

        # monta e executa a query adequada
        if len(tipos_norm) == 0:
            self.cursor.execute("SELECT numero, nome FROM pokemon ORDER BY numero")
        elif len(tipos_norm) == 1:
            t = tipos_norm[0]
            self.cursor.execute("""
                                SELECT numero, nome
                                FROM pokemon
                                WHERE LOWER(tipo1) = ?
                                   OR LOWER(tipo2) = ?
                                ORDER BY numero
                                """, (t, t))
        else:  # 2 tipos: precisa ter ambos (independente da ordem)
            t1, t2 = tipos_norm[0], tipos_norm[1]
            self.cursor.execute("""
                                SELECT numero, nome
                                FROM pokemon
                                WHERE (LOWER(tipo1) = ? AND LOWER(tipo2) = ?)
                                   OR (LOWER(tipo1) = ? AND LOWER(tipo2) = ?)
                                ORDER BY numero
                                """, (t1, t2, t2, t1))

        rows = self.cursor.fetchall()

        # popula a lista (limpando antes)
        self.lista.clear()
        for numero, nome in rows:
            self.lista.addItem(f"{numero:04d} - {nome}")

    def __init__(self):
        super().__init__()
        self.conn = sqlite3.connect("pokemons.db")
        self.cursor = self.conn.cursor()
        self.setWindowTitle("Pokedex")
        self.setupUi(self)

        # layout do grid (já vindo do Designer)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setSpacing(0)

        # --- Criando botões de tipos e guardando referências ---
        types = ["normal", "fighting", "flying", "poison", "ground",
                 "rock", "bug", "ghost", "steel", "psychic",
                 "fire", "water", "grass", "electric", "dark",
                 "ice", "dragon", "fairy"]

        self.botoes_tipos = {}  # map tipo_str -> QPushButton
        for i, t in enumerate(types):
            btn = QPushButton()
            btn.setIcon(QIcon(f"asset/typeicon/{t}.png"))
            btn.setIconSize(QSize(50, 50))
            btn.setFixedSize(63, 63)
            btn.setCheckable(True)
            btn.setProperty("tipo", t)  # guarda o identificador (lowercase)
            btn.clicked.connect(self.aplicar_filtro)  # conecta à lógica de filtro
            self.gridLayout.addWidget(btn, i // 5, i % 5, Qt.AlignHCenter)
            self.botoes_tipos[t] = btn

        # === Botões de Geração ===
        gens = list(range(1, 11))  # Gen I até Gen X
        self.gen_buttons = []
        for i, g in enumerate(gens):
            btn = QPushButton(f"Gen {g}")
            btn.setCheckable(True)
            btn.clicked.connect(self.aplicar_filtro)
            self.gridLayout2.addWidget(btn, i // 5, i % 5, Qt.AlignHCenter)  # gridLayout_2 é só exemplo
            self.gen_buttons.append((btn, g))


        # Label da imagem no frame principal (lado esquerdo)
        self.img_label = QLabel(self.frame)
        self.img_label.setAlignment(Qt.AlignCenter)
        frame1_layout = QVBoxLayout(self.frame)
        frame1_layout.addWidget(self.img_label)

        # === ScrollArea em frame_2 (lado direito) ===
        self.scroll_area = QScrollArea(self.frame_2)
        self.scroll_area.setWidgetResizable(True)
        frame2_layout = QVBoxLayout(self.frame_2)
        frame2_layout.addWidget(self.scroll_area)

        # Lista inicial dentro do scroll
        self.lista = QListWidget()
        self.scroll_area.setWidget(self.lista)

        # conecta clique da lista (apenas uma vez)
        self.lista.itemClicked.connect(self.mostrar_pokemon)

        # carregar nomes (lista inicial sem filtro)
        self.filtrar_pokemons([])  # popula a lista com todos inicialmente

        # Label da imagem no frame principal
        self.img_label = QLabel(self.frame)
        self.img_label.setAlignment(Qt.AlignCenter)
        frame1_layout = QVBoxLayout(self.frame)
        frame1_layout.addWidget(self.img_label)

        # === ScrollArea em frame_2 ===
        self.scroll_area = QScrollArea(self.frame_2)
        self.scroll_area.setWidgetResizable(True)
        frame2_layout = QVBoxLayout(self.frame_2)
        frame2_layout.addWidget(self.scroll_area)

        # Lista inicial dentro do scroll
        self.lista = QListWidget()
        self.scroll_area.setWidget(self.lista)
        self.lista.itemClicked.connect(self.mostrar_pokemon)

        # carregar nomes
        self.carregar_pokemons()

        # conectar clique
        self.lista.itemClicked.connect(self.mostrar_pokemon)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Pokedex()
    window.show()
    sys.exit(app.exec())
