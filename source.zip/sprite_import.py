import os
import requests
import time

# === CONFIG ===
IMG_DIR = "images"
START_ID = 710
END_ID = 1080  # pode trocar para 1010 se quiser todos
REQUEST_SLEEP = 0.25

os.makedirs(IMG_DIR, exist_ok=True)

session = requests.Session()
session.headers.update({"User-Agent": "Pokemon-Sprite-Downloader/1.0"})


def get_sprites(pokemon_id):
    """Consulta a PokéAPI e retorna URLs do sprite normal e shiny"""
    url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_id}/"
    r = session.get(url, timeout=10)
    if r.status_code != 200:
        print(f"[!] Erro {r.status_code} no ID {pokemon_id}")
        return None, None
    data = r.json()
    sprite = data["sprites"]["front_default"]
    sprite_shiny = data["sprites"]["front_shiny"]
    return sprite, sprite_shiny


def download_image(url, filepath):
    try:
        r = session.get(url, timeout=10)
        if r.status_code == 200:
            with open(filepath, "wb") as f:
                f.write(r.content)
            print(f"✔ Baixado: {filepath}")
        else:
            print(f"[!] Erro {r.status_code} ao baixar {url}")
    except Exception as e:
        print(f"[!] Falha ao baixar {url}: {e}")


for pid in range(START_ID, END_ID + 1):
    sprite, sprite_shiny = get_sprites(pid)
    if not sprite and not sprite_shiny:
        continue

    base_name = f"{pid:04d}"  # sempre 4 dígitos

    # Sprite normal
    if sprite:
        normal_path = os.path.join(IMG_DIR, f"{base_name}.png")
        if not os.path.exists(normal_path):
            download_image(sprite, normal_path)
            time.sleep(REQUEST_SLEEP)
        else:
            print(f"⏩ Já existe: {normal_path}")

    # Sprite shiny
    if sprite_shiny:
        shiny_path = os.path.join(IMG_DIR, f"{base_name}s.png")
        if not os.path.exists(shiny_path):
            download_image(sprite_shiny, shiny_path)
            time.sleep(REQUEST_SLEEP)
        else:
            print(f"⏩ Já existe: {shiny_path}")

print("✅ Download finalizado!")
