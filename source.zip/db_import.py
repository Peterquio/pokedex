import requests
import sqlite3
import time
import sys
from typing import Optional

# CONFIG
DB_PATH = "pokemons.db"
MAX_ID = 1025         # ajuste para o máximo que você quer tentar (ex: 151, 905, 1010...)
REQUEST_SLEEP = 0.15  # tempo entre requests

session = requests.Session()
session.headers.update({"User-Agent": "PokéDB-Builder/1.0"})

# --- Abre DB e garante colunas necessárias ---
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS pokemon(
    numero INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    geracao INTEGER,
    tipo1 TEXT NOT NULL,
    tipo2 TEXT,
    altura REAL,
    peso REAL,
    pre_evolucoes TEXT,
    evolucoes TEXT,
    ps INTEGER,
    ataque INTEGER,
    defesa INTEGER,
    ataque_especial INTEGER,
    defesa_especial INTEGER,
    velocidade INTEGER,
    descricao TEXT
)
""")
conn.commit()

# Se o DB já existia sem as colunas sprite, adiciona-as (se necessário)
#cur.execute("PRAGMA table_info(pokemon)")
#cols = [r[1] for r in cur.fetchall()]
#if "sprite" not in cols:
#    cur.execute("ALTER TABLE pokemon ADD COLUMN sprite TEXT")
#if "sprite_shiny" not in cols:
#    cur.execute("ALTER TABLE pokemon ADD COLUMN sprite_shiny TEXT")
#conn.commit()

# Map para conversão segura de romano -> inteiro
roman_map = {
    "i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5,
    "vi": 6, "vii": 7, "viii": 8, "ix": 9, "x": 10
}

def safe_get_json(url: str, tries: int = 3, backoff: float = 0.5) -> Optional[dict]:
    for attempt in range(tries):
        try:
            r = session.get(url, timeout=10)
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 404:
                return None
            else:
                # para códigos 5xx tente de novo
                time.sleep(backoff * (attempt + 1))
        except Exception:
            time.sleep(backoff * (attempt + 1))
    return None

def extract_evolution_chain_names(chain_node):
    names = []
    def traverse(node):
        names.append(node["species"]["name"])
        for evo in node.get("evolves_to", []):
            traverse(evo)
    traverse(chain_node)
    # capitalizar para consistência com o resto do script
    return [n.capitalize() for n in names]

def get_pokemon_data(pokemon_id: int):
    url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_id}/"
    species_url = f"https://pokeapi.co/api/v2/pokemon-species/{pokemon_id}/"

    r = safe_get_json(url)
    if r is None:
        raise ValueError(f"Pokémon {pokemon_id} não encontrado (404).")

    s = safe_get_json(species_url)
    if s is None:
        raise ValueError(f"Species {pokemon_id} não encontrada.")

    nome = r["name"].capitalize()
    numero = r["id"]
    altura = r.get("height", 0) / 10.0
    peso = r.get("weight", 0) / 10.0
    tipos = [t["type"]["name"].capitalize() for t in r.get("types", [])]
    tipo1 = tipos[0] if tipos else None
    tipo2 = tipos[1] if len(tipos) > 1 else None

    stats = {stat["stat"]["name"]: stat["base_stat"] for stat in r.get("stats", [])}
    ps = stats.get("hp")
    ataque = stats.get("attack")
    defesa = stats.get("defense")
    ataque_especial = stats.get("special-attack")
    defesa_especial = stats.get("special-defense")
    velocidade = stats.get("speed")

    # geração: extrai a parte depois do '-' e usa o mapa
    gen_name = s.get("generation", {}).get("name", "")
    roman = gen_name.split("-")[-1].lower() if gen_name else ""
    geracao = roman_map.get(roman)

    # descrição: prefere pt então en
    descricao = ""
    for entry in s.get("flavor_text_entries", []):
        if entry.get("language", {}).get("name") == "pt":
            descricao = entry.get("flavor_text", "").replace("\n", " ").replace("\f", " ")
            break
    if not descricao:
        for entry in s.get("flavor_text_entries", []):
            if entry.get("language", {}).get("name") == "en":
                descricao = entry.get("flavor_text", "").replace("\n", " ").replace("\f", " ")
                break

    # evoluções: pega a cadeia e extrai todos os nomes (cobre ramificações)
    evo_chain_url = s.get("evolution_chain", {}).get("url")
    pre_evolucoes = None
    evolucoes = None
    if evo_chain_url:
        evo_chain = safe_get_json(evo_chain_url)
        if evo_chain:
            full_chain = extract_evolution_chain_names(evo_chain["chain"])
            # encontra índice com comparação case-insensitive
            lower_chain = [n.lower() for n in full_chain]
            try:
                idx = lower_chain.index(nome.lower())
                pre = full_chain[:idx]
                post = full_chain[idx+1:]
                pre_evolucoes = ", ".join(pre) if pre else None
                evolucoes = ", ".join(post) if post else None
            except ValueError:
                # nome não encontrado na chain (raro), deixa None
                pre_evolucoes = None
                evolucoes = None

    return (
        numero, nome, geracao, tipo1, tipo2, altura, peso,
        pre_evolucoes, evolucoes,
        ps, ataque, defesa, ataque_especial, defesa_especial, velocidade,
        descricao
    )

# --- Descobre IDs já existentes e calcula faltantes ---
cur.execute("SELECT numero FROM pokemon")
existing_ids = set(row[0] for row in cur.fetchall())

desired_range = set(range(1, MAX_ID + 1))
missing_ids = sorted(list(desired_range - existing_ids))

if not missing_ids:
    print("Nenhum pokémon faltante no intervalo especificado. Nada a fazer.")
    conn.close()
    sys.exit(0)

print(f"Encontrados {len(missing_ids)} pokémons faltantes (IDs entre 1 e {MAX_ID}).")

errors = []
inserted = 0

for pid in missing_ids:
    try:
        time.sleep(REQUEST_SLEEP)
        data = get_pokemon_data(pid)
        # usa INSERT OR REPLACE caso queira sobrescrever se algo mudou; aqui inserimos
        cur.execute("""
            INSERT OR REPLACE INTO pokemon (
                numero, nome, geracao, tipo1, tipo2, altura, peso,
                pre_evolucoes, evolucoes,
                ps, ataque, defesa, ataque_especial, defesa_especial, velocidade,
                descricao
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, data)
        conn.commit()
        inserted += 1
        print(f"✔ Inserido: {pid} - {data[1]}")
    except Exception as e:
        err_msg = f"Erro ID {pid}: {e}"
        print(err_msg)
        errors.append(err_msg)

# grava erros em arquivo para retry manual
if errors:
    with open("errors.log", "a", encoding="utf-8") as f:
        f.write("\n".join(errors) + "\n")
    print(f"{len(errors)} erros foram gravados em errors.log")

print(f"Concluído. Inseridos: {inserted}. Erros: {len(errors)}")
conn.close()